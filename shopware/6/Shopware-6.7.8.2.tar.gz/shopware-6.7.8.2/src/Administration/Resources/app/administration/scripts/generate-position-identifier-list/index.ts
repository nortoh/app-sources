/**
 * @package admin
 * @private
 */

import fs from 'fs';
import path from 'path';
import cliProgress from 'cli-progress';
import colors from 'picocolors';

/**
 * Recursively get all files from a directory
 */
function getAllFiles(dirPath: string, arrayOfFiles: string[] = []): string[] {
    const files = fs.readdirSync(dirPath);

    // Ensure arrayOfFiles is initialized
    arrayOfFiles = arrayOfFiles || [];

    files.forEach((file) => {
        if (fs.statSync(`${dirPath}/${file}`).isDirectory()) {
            // If the file is a directory, recursively get its files
            arrayOfFiles = getAllFiles(`${dirPath}/${file}`, arrayOfFiles);
        } else {
            arrayOfFiles.push(path.join(dirPath, '/', file));
        }
    });

    return arrayOfFiles;
}

// Get all HTML Twig template files from the specified directory
const templateFiles = getAllFiles(path.join(__dirname, '../../src')).filter(file => {
    return file.match(/^.*\.html\.twig$/);
});

console.log(colors.blue('Gathering position identifiers...\n'));

// Create and start a progress bar
const pb = new cliProgress.SingleBar({}, cliProgress.Presets.shades_classic);
pb.start(templateFiles.length, 0);

let result: string[] = [];
templateFiles.forEach((file) => {
    // Increment the progress bar for each file processed
    pb.increment();

    const fileContent = fs.readFileSync(file, { encoding: 'utf-8' });
    if (!fileContent.includes('position-identifier="')) {
        return;
    }

    // Find all position identifiers in the file and add them to the result
    [...fileContent.matchAll(/position-identifier="(.+)"/gm)].map((match) => match[1]).forEach((match) => {
        result.push(match);
    });
})

// Stop the progress bar
pb.stop();

// Sort the result array to maintain consistent ordering
const sortedPositionIdentifiers = result.sort((a, b) => a.localeCompare(b));

// Define the output file path for the result
const outputFile = path.join(__dirname, '../../src/meta/position-identifiers.json');

console.log(colors.blueBright(`\nWriting to ${outputFile}`));

fs.writeFileSync(outputFile, JSON.stringify(sortedPositionIdentifiers, null, 1));

console.log(colors.green('\nAll done!'));
