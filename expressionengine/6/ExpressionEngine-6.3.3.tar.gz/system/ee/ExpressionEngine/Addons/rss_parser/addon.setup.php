<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'RSS Parser',
    'description' => 'Retrieves and Parses RSS/Atom Feeds',
    'version' => '2.0.0',
    'namespace' => 'ExpressionEngine\Addons\RssParser',
    'settings_exist' => false
);

// EOF
