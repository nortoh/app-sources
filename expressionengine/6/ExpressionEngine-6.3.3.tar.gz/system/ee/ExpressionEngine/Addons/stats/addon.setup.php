<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Stats',
    'description' => 'Tracks a number of system statistics',
    'version' => '2.2.0',
    'namespace' => 'ExpressionEngine\Addons\Stats',
    'settings_exist' => false,
);
