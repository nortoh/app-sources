<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'File',
    'description' => '',
    'version' => '1.1.0',
    'namespace' => 'ExpressionEngine\Addons\File',
    'settings_exist' => false,
    'built_in' => true,
    'fieldtypes' => array(
        'file' => array(
            'compatibility' => 'file'
        )
    )
);
