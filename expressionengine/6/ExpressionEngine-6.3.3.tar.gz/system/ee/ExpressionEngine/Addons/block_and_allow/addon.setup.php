<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Block and Allow',
    'description' => 'Block/allow IP Addresses, URLs, and User-Agents',
    'version' => '3.0.1',
    'namespace' => 'ExpressionEngine\Addons\Block_and_allow',
    'settings_exist' => true,
);
