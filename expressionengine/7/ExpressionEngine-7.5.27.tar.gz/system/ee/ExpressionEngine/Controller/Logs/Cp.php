<?php
/**
 * This source file is part of the open source project
 * ExpressionEngine (https://expressionengine.com)
 *
 * @link      https://expressionengine.com/
 * @copyright Copyright (c) 2003-2026, Packet Tide, LLC (https://www.packettide.com)
 * @license   https://expressionengine.com/license Licensed under Apache License, Version 2.0
 */

namespace ExpressionEngine\Controller\Logs;

/**
 * Logs\CP Controller
 */
class Cp extends Logs
{
    /**
     * View Control Panel Log Files
     *
     * Shows the control panel action log
     *
     * @access	public
     * @return	mixed
     */
    public function index()
    {
        ee('CP/Alert')->makeDeprecationNotice()->now();

        if (ee()->input->post('delete')) {
            $this->delete('CpLog', lang('cp_log'));
            if (strtolower(ee()->input->post('delete')) == 'all') {
                return ee()->functions->redirect(ee('CP/URL')->make('logs/cp'));
            }
        }

        $this->base_url->path = 'logs/cp';
        ee()->view->cp_page_title = lang('view_cp_log');

        $sites = ee('Model')->get('Site');
        $logs = ee('Model')->get('CpLog');

        $search = null;
        $keyword_post = ee()->input->post('filter_by_keyword');
        $is_clearing_keyword = ($keyword_post !== false && trim((string) $keyword_post) === '');

        // CP logs only: when keyword is intentionally cleared via POST,
        // prevent GET fallback from rehydrating the previous keyword value.
        if ($is_clearing_keyword) {
            unset($_GET['filter_by_keyword']);
        }

        if (! $is_clearing_keyword && ($search = ee()->input->get_post('filter_by_keyword'))) {
            $logs->search(['action', 'username', 'ip_address'], $search);
        }

        $filters = ee('CP/Filter')
            ->add('Username')
            ->add('Site')
            ->add('Date')
            ->add('Keyword')
            ->add('Perpage', $logs->count(), 'all_cp_logs');
        ee()->view->filters = $filters->render($this->base_url);
        $this->params = $filters->values();
        $this->base_url->addQueryStringVariables($this->params);

        $page = ((int) ee()->input->get('page')) ?: 1;
        $offset = ($page - 1) * $this->params['perpage']; // Offset is 0 indexed

        if (! empty($this->params['filter_by_username'])) {
            $logs = $logs->filter('member_id', 'IN', $this->params['filter_by_username']);
        }

        if (! empty($this->params['filter_by_site'])) {
            $logs = $logs->filter('site_id', $this->params['filter_by_site']);
            $sites = $sites->filter('site_id', $this->params['filter_by_site']);
        }

        if (! empty($this->params['filter_by_date'])) {
            if (is_array($this->params['filter_by_date'])) {
                $logs = $logs->filter('act_date', '>=', $this->params['filter_by_date'][0]);
                $logs = $logs->filter('act_date', '<', $this->params['filter_by_date'][1]);
            } else {
                $logs = $logs->filter('act_date', '>=', ee()->localize->now - $this->params['filter_by_date']);
            }
        }

        $count = $logs->count();

        // Set the page heading
        if (! empty($search)) {
            ee()->view->cp_heading = sprintf(
                lang('search_results_heading'),
                $count,
                ee('Format')->make('Text', $search)->convertToEntities()
            );
        }

        ee()->view->header = array(
            'title' => lang('system_logs'),
            'form_url' => $this->base_url->compile(),
        );

        $logs = $logs->order('act_date', 'desc')
            ->limit($this->params['perpage'])
            ->offset($offset)
            ->all();

        $pagination = ee('CP/Pagination', $count)
            ->perPage($this->params['perpage'])
            ->currentPage($page)
            ->render($this->base_url);

        $vars = array(
            'logs' => $logs,
            'sites' => $sites->all(),
            'pagination' => $pagination,
            'form_url' => $this->base_url->compile(),
        );

        ee()->view->cp_breadcrumbs = array(
            '' => lang('view_cp_log')
        );

        ee()->cp->render('logs/cp', $vars);
    }
}
// END CLASS

// EOF
