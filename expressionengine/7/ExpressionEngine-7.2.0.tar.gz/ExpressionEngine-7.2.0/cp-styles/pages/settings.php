<?php $page_title = 'Settings'; include(dirname(__FILE__) . '/_wrapper-head.php'); ?>


<?php include(dirname(__FILE__) . '/_wrapper-footer.php'); ?>
