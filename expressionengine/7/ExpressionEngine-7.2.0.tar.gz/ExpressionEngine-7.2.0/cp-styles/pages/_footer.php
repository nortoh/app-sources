

    <script src="../build/vendor.js"></script>
    <script src="../build/main.min.js"></script>
    <script>
		var Main = require('main.ts')
    </script>
</body>
</html>
