<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Pages',
    'description' => 'Create single pages that are attached to channel entries',
    'version' => '2.2.0',
    'namespace' => 'ExpressionEngine\Addons\Foo',
    'settings_exist' => true,
);
