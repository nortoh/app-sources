<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Channel',
    'description' => '',
    'version' => '2.1.0',
    'namespace' => 'ExpressionEngine\Addons\Channel',
    'settings_exist' => true,
    'built_in' => true,
);
