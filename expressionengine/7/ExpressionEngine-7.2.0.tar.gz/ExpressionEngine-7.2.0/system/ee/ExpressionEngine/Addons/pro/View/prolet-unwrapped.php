<?php $this->extend('ee:_shared/iframe-modal'); ?>
<div class="container">
    <?=$output?>
</div>
