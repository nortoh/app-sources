<?php $this->extend('ee:_shared/iframe-modal'); ?>
<div class="panel">
    <div class="panel-body">
        <?=$output?>
    </div>
</div>
