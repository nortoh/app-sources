<div class="fluid" data-field-count="0">
	<div class="js-sorting-container">
		<?=$fields?>
	</div>
	<div class="fluid__footer">
		<?=$filters?>
	</div>
	<div class="fluid-field-templates hidden">
		<?=$field_templates?>
	</div>
</div>
