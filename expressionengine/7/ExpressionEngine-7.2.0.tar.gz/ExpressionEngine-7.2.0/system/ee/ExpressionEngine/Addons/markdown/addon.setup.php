<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Markdown',
    'description' => 'Parse text using Markdown and Smartypants',
    'version' => '2.0.0',
    'namespace' => 'ExpressionEngine\Addons\Markdown',
    'settings_exist' => false,
    'plugin.typography' => true
);

// EOF
