<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'ExpressionEngine FilePicker',
    'description' => "The world's most flexible file picker.",
    'version' => '1.0.0',
    'namespace' => 'ExpressionEngine\Addons\FilePicker',
    'settings_exist' => true,
    'built_in' => true
);
