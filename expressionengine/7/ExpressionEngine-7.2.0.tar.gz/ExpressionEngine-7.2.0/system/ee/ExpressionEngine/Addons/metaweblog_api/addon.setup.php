<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'Metaweblog_api',
    'description' => 'Post and edit entries using a Metaweblog API-compatible program',
    'version' => '2.3.0',
    'namespace' => 'ExpressionEngine\Addons\MetaweblogApi',
    'settings_exist' => true,
);
