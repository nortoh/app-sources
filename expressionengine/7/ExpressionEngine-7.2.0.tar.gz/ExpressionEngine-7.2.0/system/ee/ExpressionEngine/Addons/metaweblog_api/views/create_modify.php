<div class="box">
	<?php $this->embed('ee:_shared/form')?>
</div>
