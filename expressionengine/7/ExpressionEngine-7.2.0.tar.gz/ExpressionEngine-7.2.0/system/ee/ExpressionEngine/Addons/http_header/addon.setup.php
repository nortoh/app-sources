<?php

return array(
    'author' => 'ExpressionEngine',
    'author_url' => 'https://expressionengine.com/',
    'name' => 'HTTP Header',
    'description' => 'Set HTTP Headers in your templates',
    'version' => '1.0.0',
    'namespace' => 'ExpressionEngine\Addons\HTTPHeader',
    'settings_exist' => false,
    'built_in' => false,
);
