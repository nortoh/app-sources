---
name: 📝 Documentation Issue
about: See https://github.com/ExpressionEngine/ExpressionEngine-User-Guide/issues for User Guide issues

---

The ExpressionEngine User Guide has its own dedicated repository. Please open your documentation-related issue at https://github.com/ExpressionEngine/ExpressionEngine-User-Guide/issues.

Thank you! 🙏