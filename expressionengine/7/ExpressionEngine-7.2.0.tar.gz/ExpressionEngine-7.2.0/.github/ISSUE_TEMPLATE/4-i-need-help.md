---
name: ⁉️ I Need Help!
about: Questions, support, and similar "I need assistance" requests.

---

The GitHub issue tracker is for bug reports and feature requests **only**. Support questions will be closed without warning for project maintainer sanity. Here are some places you can get help fast!

- ExpressionEngine Forums: https://expressionengine.com/forums
- ExpressionEngine Slack: https://expressionengine.com/blog/join-us-in-slack#join-us-on-slack
- ExpressionEngine StackExchange: https://expressionengine.stackexchange.com/
- Twitter: Tiny questions, using the #eecms hashtag
- First-party support from Packet Tide: https://expressionengine.com/support

Thank you! 🙏
