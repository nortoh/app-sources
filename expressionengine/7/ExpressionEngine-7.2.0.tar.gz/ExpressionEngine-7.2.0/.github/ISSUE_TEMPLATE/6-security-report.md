---
name: ⚠️ Security Report
about: See https://docs.expressionengine.com/latest/bugs-and-security-reports.html for reporting security issues.

---

Do not file security reports publicly. Please follow the guide at https://docs.expressionengine.com/latest/bugs-and-security-reports.html for responsible security reporting.

Thank you! 🙏
