<?php

return array(
	'author'      => 'Example Inc.',
	'author_url'  => 'http://example.com/',
	'name'        => 'Test Three',
	'description' => '',
	'version'     => '1.3',
	'namespace'   => 'Example\Test\Three',
	'settings_exist' => FALSE,

	'plugin.typography' => TRUE
);