<?php

class Test_one {

	public $return_data;

	public function __construct($tagdata = '')
	{
		return "Test One";
	}

}

// EOF
