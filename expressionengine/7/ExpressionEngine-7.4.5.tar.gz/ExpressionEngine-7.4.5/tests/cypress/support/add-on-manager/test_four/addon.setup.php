<?php

return array(
	'author'      => 'Example Inc.',
	'author_url'  => 'http://example.com/',
	'name'        => 'Test Four',
	'description' => '',
	'version'     => '1.4',
	'namespace'   => 'Example\Test\Four',
	'settings_exist' => FALSE,

	'plugin.typography' => TRUE
);