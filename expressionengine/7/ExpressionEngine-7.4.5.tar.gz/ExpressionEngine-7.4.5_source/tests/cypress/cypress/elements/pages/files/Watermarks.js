import FileManagerSection from '../_sections/FileManagerSection'

class Watermarks extends FileManagerSection {
  constructor() {
      super()

    }

}
export default Watermarks;