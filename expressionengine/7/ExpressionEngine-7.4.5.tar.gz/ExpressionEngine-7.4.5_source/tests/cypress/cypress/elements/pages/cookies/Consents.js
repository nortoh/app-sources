import ControlPanel from '../ControlPanel'

class Consents extends ControlPanel {
  constructor() {
    super()
    this.elements({



    })
  }
}
export default Consents;
