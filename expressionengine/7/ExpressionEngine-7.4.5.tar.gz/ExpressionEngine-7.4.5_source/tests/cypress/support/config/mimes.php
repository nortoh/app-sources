<?php

return array(
    'application/x-bittorrent', // .torrent
);

// EOF
