#!/bin/sh

rm -rf /tmp/*