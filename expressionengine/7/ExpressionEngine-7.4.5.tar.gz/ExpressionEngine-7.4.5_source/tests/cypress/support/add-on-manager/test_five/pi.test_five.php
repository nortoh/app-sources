<?php

class Test_five {

	public $return_data;

	public function __construct($tagdata = '')
	{
		return "Test Five";
	}

}

// EOF
