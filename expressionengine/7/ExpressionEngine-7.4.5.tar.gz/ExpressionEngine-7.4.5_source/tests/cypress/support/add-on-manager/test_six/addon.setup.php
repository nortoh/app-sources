<?php

return array(
	'author'      => 'Test LLC',
	'author_url'  => 'http://example.com/',
	'name'        => 'Test Six',
	'description' => '',
	'version'     => '1.6',
	'namespace'   => 'Test\Test\Six',
	'settings_exist' => FALSE,

	'plugin.typography' => TRUE
);