<?php

return array(
	'author'      => 'Example Inc.',
	'author_url'  => 'http://example.com/',
	'name'        => 'Test Two',
	'description' => '',
	'version'     => '1.2',
	'namespace'   => 'Example\Test\Two',
	'settings_exist' => FALSE,

	'plugin.typography' => TRUE
);