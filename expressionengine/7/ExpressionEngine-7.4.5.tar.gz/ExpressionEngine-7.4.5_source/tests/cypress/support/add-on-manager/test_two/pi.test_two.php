<?php

class Test_two {

	public $return_data;

	public function __construct($tagdata = '')
	{
		return "Test Two";
	}

}

// EOF
