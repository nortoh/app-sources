<?php

class Test_three {

	public $return_data;

	public function __construct($tagdata = '')
	{
		return "Test Three";
	}

}

// EOF
