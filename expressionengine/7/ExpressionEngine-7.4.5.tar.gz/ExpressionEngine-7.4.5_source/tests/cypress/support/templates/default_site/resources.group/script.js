(function _() {
	var div = document.getElementById('second');

	div.style.backgroundColor = 'magenta';
})();
