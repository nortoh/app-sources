<?php

class Test_six {

	public $return_data;

	public function __construct($tagdata = '')
	{
		return "Test Six";
	}

}

// EOF
