<?php

return array(
	'author'      => 'Example Inc.',
	'author_url'  => 'http://example.com/',
	'name'        => 'Test One',
	'description' => '',
	'version'     => '1.1',
	'namespace'   => 'Example\Test\One',
	'settings_exist' => FALSE,

	'plugin.typography' => TRUE
);