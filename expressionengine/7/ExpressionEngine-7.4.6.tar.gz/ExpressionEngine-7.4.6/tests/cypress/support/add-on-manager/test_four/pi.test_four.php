<?php

class Test_four {

	public $return_data;

	public function __construct($tagdata = '')
	{
		return "Test Four";
	}

}

// EOF
