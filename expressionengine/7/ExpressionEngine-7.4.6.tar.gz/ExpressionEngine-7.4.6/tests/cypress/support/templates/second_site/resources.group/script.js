(function _() {
	var div = document.getElementById('fourth');

	div.style.backgroundColor = 'black';
})();
