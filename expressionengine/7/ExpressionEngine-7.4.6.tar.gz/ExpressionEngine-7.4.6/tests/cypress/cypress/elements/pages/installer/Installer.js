import Updater from './Updater';


class Installer extends Updater {
  constructor() {
    super()

    this.selectors = Object.assign(this.selectors, {

    })
  }

}

export default Installer;
